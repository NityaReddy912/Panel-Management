import React, { useState } from "react";
import { Link, useParams } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import LoginPage from "./login_page/login";
import "../components/navbar.scss"
import Dropdown from 'react-bootstrap/Dropdown';

function Navbar() {
  const {id}=useParams();
  const [user,setId]=useState(id)
  console.log(id);
  return (
    <div className="wrapper  py-2 px-2">
      <nav className="navbar navbar-expand-lg navbar-dark bg-primary rounded">
        <div className="container-fluid">
          <Link to="/search" className="navbar-brand fw-bolder">
            User Management
          </Link>

          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>

          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav me-auto mb-2 mb-lg-0">
              <li className="nav-item">
                <Link to="/search" className="nav-link active" aria-current="page">
                  User
                </Link>
              </li>
            </ul>

            <Dropdown>

              <Dropdown.Toggle variant="primary" id="dropdown-basic">

                <b>{user}</b>

              </Dropdown.Toggle>
              <Dropdown.Menu>
                <Dropdown.Item href="\reset">Change Password</Dropdown.Item>
                <Dropdown.Item href="\">Logout</Dropdown.Item>
              </Dropdown.Menu>
            </Dropdown>
          </div>
        </div>
      </nav>
    </div>
  );
};

export default Navbar;
