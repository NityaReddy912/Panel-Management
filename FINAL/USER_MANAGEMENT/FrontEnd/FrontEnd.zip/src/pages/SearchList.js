//import React, { useState } from "react";
import Paginator from "./Paginator.js";
import SingleList from "./SingleList";
import "./SearchList.scss";
//import { Action } from "@remix-run/router";

function SearchList({ userList, onNext, onPrevious, page, userid, username, email, roles, isActive }) {
    return (
        <div className='container-wrap'>
            <h5> {userList.totalItems === 1 ? "1 User" : `${userList.totalItems} Users Fetched`}</h5>
            {userList?.user?.length ? (
                <Paginator
                    onPrevious={onPrevious}
                    onNext={onNext}
                    lastPage={userList ? Math.ceil(userList.totalItems / 3) : 1}
                    currentPage={page}>
                    <table className='searchList__lists'>
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>User ID</th>
                                <th>User Name</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>&nbsp;</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {userList.user?.map((user, index) => (
                                <SingleList key={user._id} hash={index + 1} user={user} page={page} />
                            ))}
                        </tbody>
                    </table>
                </Paginator>
            ) : (
                <h3 className='searchList__noResult'>
                    No Result Found For this Search
                </h3>
            )}
        </div>
    );
}

export default SearchList;