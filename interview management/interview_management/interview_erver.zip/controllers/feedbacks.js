const Feedbacks = require("../models/feedbacks");

module.exports.addFeedback = async function (request, response) {
  const id = request.body.id;
  try {
    const feedbacks = await Feedbacks.find();
    if (feedbacks.find((feedbacksObj) => feedbacksObj.id === id)) {
      return response.status(409).json({ err: "Feedback already Exists" });
    }

    const feedbacksObject = new Feedbacks({
      id: request.body.id,
      skill_name: request.body.skill_name,
      rating: request.body.rating,
      remark: request.body.remark,
      created_by: request.body.created_by,
    });
    await feedbacksObject.save();
    response.status(200).json({
      message: "FeedBack Successfully Submitted",
      feedbacksObject,
    });
  } catch (err) {
    response.status(500).json({ err: err.message });
  }
};

module.exports.searchFeedback = async function (request, res) {
  try {
    let dbConstraint = {};

    if (request.body.id) {
      dbConstraint.id = request.body.id;
    }

    const totalrecords = await Feedbacks.aggregate([
      {
        $lookup:{
          from: "interviews",
          localField:"id",
          foreignField:"feedback_id",
          as:"interviews",
        },
      },
      {
        $lookup:{
          from: "candidates",
          localField:"candidate_id",
          foreignField:"id",
          as:"candidates",
        },
      },
      {
        $match:{
          ...dbConstraint
      },
    }
    ]);
    
    
    let feedbackform = await Feedbacks.find({ ...dbConstraint });

    if (feedbackform.length === 0) {
      return res
        .status(404)
        .json({ message: "Scheduled Interveiws details not found" });
    }
    res.status(200).json({
      message: "Successfully Fetched the Scheduled Interveiws",
      feedbackform: feedbackform,
    });
  } catch (err) {
    res.status(500).json({ err: err.message });
  }
};


module.exports.getAllFeedBackForms = async function (request, response) {
  try {
    const feedbackforms = await Feedbacks.find();
    if (feedbackforms === 0) {
      return response.status(404).json({ message: "FeedbackForms not found" });
    }
    response
      .status(200)
      .json({ message: "Successfully Fetched the User", feedbackforms });
  } catch (err) {
    response.status(500).json({ err: err.message });
  }
};

module.exports.getById = async function(request, response) {
  try {
    const feedbackform = await Feedbacks.find({
      id: request.params.id,
    });

    if (feedbackform === 0) {
      return response.status(404).json({ message: "Feedback Form  not found" });
    }

    response
      .status(200)
      .json({ message: "Successfully Fetched the FeedBackForm", feedbackform });
  } catch (err) {
    response.status(500).json({ err: err.message });
  }
}
