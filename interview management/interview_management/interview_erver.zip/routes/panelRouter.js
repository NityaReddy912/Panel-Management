const express = require('express');

const{
    panels_availability,
    addpanel,
    search,
} = require('../controllers/panelSearch');

const router = express.Router();


router.post("/addPanel", addpanel);
router.post("/addPanelAvail", panels_availability);
router.post("/search", search);


module.exports = router;
