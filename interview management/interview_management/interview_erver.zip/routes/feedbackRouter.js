const express = require('express');

const{
    addFeedback,
    searchFeedback,
    getAllFeedBackForms,
    getById,
} = require('../controllers/feedbacks');

const router = express.Router();


router.post("/addfeedback", addFeedback);
router.post("/getallfeedback", getAllFeedBackForms);
router.post("/searchFeedback", searchFeedback);
router.post("/getbyId", getById);



module.exports = router;
