import SingleList from "./Singlelist";
import "./SearchList.scss";
import Paginator from "../Utils/Paginator";
//import { Action } from "@remix-run/router";

function SearchList({
  candidateList,
  onNext,
  onPrevious,
  page,
  isLoading,
  CandidateName,
  Email,
  Role,
  status,
}) {
  console.log(candidateList);
  return (
    <>
      {!isLoading && (
        <div className='container-wrap px-2'>
          {candidateList?.candidate?.length ? (
            <>
              <Paginator
                onPrevious={onPrevious}
                onNext={onNext}
                lastPage={
                  candidateList
                    ? Math.ceil(
                        candidateList.totalItems / 3,
                      )
                    : 1
                }
                currentPage={page}>
                <table className='searchList__lists my-1'>
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Candidate Name</th>
                      <th>Candidate Email</th>
                      <th>Candidate Contact</th>
                      <th>PAN</th>
                      <th>Role</th>
                      <th>Experience</th>
                      <th>Status</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {candidateList.candidate?.map(
                      (candidate, index) => (
                        <SingleList
                          key={candidate.cid}
                          hash={page * 3 - 3 + (index + 1)}
                          candidate={candidate}
                          id={candidate._id}
                        />
                      ),
                    )}
                  </tbody>
                </table>
                {!candidateList.totalItems ? null : (
                  <span className=''>
                    {page * 3 -
                      2 +
                      " - " +
                      (page * 3 <= candidateList.totalItems
                        ? page * 3
                        : candidateList.totalItems) +
                      " of " +
                      Math.ceil(candidateList.totalItems) +
                      " records"}
                  </span>
                )}
              </Paginator>
            </>
          ) : (
            <h3 className='searchList__noResult'>
              No Result Found For this Search
            </h3>
          )}
          {/* <br></br> */}
        </div>
      )}
    </>
  );
}

export default SearchList;
