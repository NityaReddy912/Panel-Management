import React, { useEffect, useState } from "react";
// import { Link } from "react-router-dom";
// import PhoneInput from "react-phone-number-input";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import Headers from "../Utils/Headers";
import validator from "validator";

function AddUser() {
  const [username, setUserName] = useState("");
  const [userid, setUserId] = useState("");
  const [email, setEmail] = useState("");
  const [roles, setRoles] = useState("");
  const [isActive, setIsActive] = useState(false);
  const [roleList, setRoleList] = useState([]);
  const navigate = useNavigate();
  const user_data = JSON.parse(
    window.sessionStorage.getItem("user_data"),
  );
  const logged_user = user_data.name;

  useEffect(() => {
    let isApiSubscribed = true;
    const getRoles = async () => {
      const roleListResponse = await fetch(
        `http://localhost:5000/role/all`,
        {
          headers: {
            "x-access-token":
              window.sessionStorage.getItem("token"),
          },
        },
      );

      const roleListData = await roleListResponse.json();
      console.log(roleListData);

      setRoleList(roleListData);
    };

    if (isApiSubscribed) {
      getRoles();
    }

    return () => {
      isApiSubscribed = false;
    };
  }, []);

  const handleCancel = (e) => {
    e.preventDefault();
    setUserName("");
    setEmail("");
    setUserId("");
    setRoles("");
    setIsActive(false);
    navigate("/user");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    var check_email = email;
    if (validator.isEmail(check_email)) {
      //toast.success('Valid Email',{autoClose:1000})
    } else {
      return toast.error("Enter valid Email!", {
        autoClose: 1000,
      });
    }
    const user = {
      username,
      roles,
      userid,
      email,
      isActive,
    };
    console.log(user);
    const result = await fetch(
      "http://localhost:8080/addUser",
      {
        method: "POST",
        headers: {
          "x-access-token":
            window.sessionStorage.getItem("token"),
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          user_id: userid,
          name: username,
          email: email,
          is_active: isActive,
          created_by: logged_user,
          role_id: roles,
        }),
      },
    );
    const data = await result.json();
    if (result.status === 404) {
      return toast.error("Please Enter All Fields", {
        autoClose: 1000,
      });
    }
    if (result.status === 409) {
      return toast.error("User Already Exists", {
        autoClose: 1000,
      });
    }
    if (result.status === 500) {
      return toast.error("Server Trashed", {
        autoClose: 1000,
      });
    }
    if (result.status === 200) {
      toast.success("Successfully Added New User", {
        autoClose: 1000,
      });
      navigate("/user");
    }
  };

  return (
    <div className='p-2'>
      <div className='App'>
        <Headers />
      </div>
      <div className='container-wrap p-3'>
        <h2
          className='mb-4 '
          data-testid='AddUser'>
          Add User
        </h2>
        <form>
          <div className='row mb-3'>
            <div className='col-md-1'>
              <div className='form-group px-2'>
                <label
                  className='fw-bolder  '
                  htmlFor='first'>
                  User Id
                </label>
              </div>
            </div>

            <div className='col-md-4'>
              <div className='form-group'>
                <input
                  type='text'
                  className='form-control'
                  value={userid}
                  onChange={(e) =>
                    setUserId(e.target.value)
                  }
                  placeholder='Enter User Id'
                />
              </div>
            </div>
            <div className='col-sm-1'></div>
            <div className='col-md-1'>
              <div className='form-group px-2'>
                <label
                  className='fw-bolder '
                  htmlFor='first'>
                  User Name
                </label>
              </div>
            </div>

            <div className='col-md-4'>
              <div className='form-group '>
                <input
                  type='text'
                  className='form-control'
                  placeholder='Enter User Name'
                  value={username}
                  onChange={(e) =>
                    setUserName(e.target.value)
                  }
                />
              </div>
            </div>
          </div>
          <div className='row mb-3'>
            <div className='col-md-1 '>
              <div className='form-group px-2'>
                <label
                  className='fw-bolder'
                  htmlFor='first'>
                  Email
                </label>
              </div>
            </div>

            <div className='col-md-4'>
              <div className='form-group '>
                <input
                  type='text'
                  className='form-control'
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder='Enter Email Id'
                />
              </div>
            </div>
            <div className='col-sm-1'></div>
            <div className='col-md-1'>
              <div className='form-group px-2'>
                <label
                  className='fw-bolder'
                  htmlFor='first'>
                  User Role
                </label>
              </div>
            </div>

            <div className='col-md-4'>
              <div className='form-group'>
                <select
                  onChange={(e) => setRoles(e.target.value)}
                  id='select'
                  className='form-select'
                  aria-label='Select Role'>
                  <option
                    value=''
                    data-testid='selectRole'>
                    Select Role
                  </option>
                  {roleList?.role &&
                    roleList?.role.map(
                      (role) =>
                        role?.is_deleted && (
                          <option value={role.role_id}>
                            {role.role_name}
                          </option>
                        ),
                    )}
                </select>
              </div>
            </div>
          </div>

          <div className='row g-3'>
            <div className='col-sm-1 '>
              <label className='fw-bolder px-2 py-1'>
                isActive
              </label>
            </div>
            &nbsp;&nbsp;
            <div className='col-sm-3 form-check form-switch'>
              <input
                className='form-check-input'
                type='checkbox'
                role='switch'
                id='flexSwitchCheckDefault'
                data-testid='checkbox'
                value={isActive}
                onChange={(e) =>
                  setIsActive(e.target.checked)
                }
              />
            </div>
          </div>
          <div className='row addList__button'>
            <div className='col-md-2'>
              <button
                type='submit'
                onClick={handleSubmit}
                className='btn btn-primary'
                data-testid='submit'>
                Submit
              </button>
            </div>
            <div className='col-md-3'>
              <button
                onClick={handleCancel}
                className='btn btn-primary'
                type='button'
                data-testid='button'>
                Cancel
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}

export default AddUser;
