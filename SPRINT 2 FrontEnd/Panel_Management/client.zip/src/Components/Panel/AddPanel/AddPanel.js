import React, {
  createElement,
  useEffect,
  useState,
} from "react";
import "./addPanel.css";
import { BsTrashFill } from "react-icons/bs";

function AddPanel() {
  const [tableData, setTableData] = useState([
    { role: "", interviewType: "", isActive: false },
  ]);

  function refreshDataRole(e, index) {
    let temp = tableData;
    temp.map((item, i) => {
      if (i === index) {
        item.role = e.target.value;
      }
    });
    setTableData([...temp]);
  }

  function deleteRow(e, index) {
    let temp = tableData;
    temp.splice(index, 1);
    setTableData([...temp]);
  }

  function refreshDataIntType(e, i) {
    let temp = tableData;
    temp = temp.map((item, index) => {
      if (i === index) {
        item.interviewType = e.target.value;
      }
      return item;
    });
    setTableData([...temp]);
  }

  function refreshDataActive(e, index) {
    let temp = tableData;
    temp = temp.map((item, i) => {
      if (i === index) {
        item.isActive = e.target.checked;
      }
    });
  }

  function addNewRole() {
    setTableData([
      ...tableData,
      { role: "", interviewType: "" },
    ]);
  }

  useEffect(() => {
    console.log(tableData);
  }, [tableData]);

  return (
    <div className='container-wrap px-1'>
      <div className='row'>
        <div className='col-md-12 '>
          <h2>Add Panel</h2>
        </div>
      </div>
      <div className='container-wrap'>
        <form>
          <div className='row mb-3'>
            <div className='col-md-1'>
              <div className='form-group'>
                <label
                  className='fw-bolder  '
                  for=''>
                  Associate ID
                </label>
              </div>
            </div>
            <div className='col-md-4'>
              <div className='form-group'>
                <input
                  type='text'
                  className='form-control'
                  placeholder='Enter Associate ID'
                />
              </div>
            </div>

            <div className='col-sm-1'></div>

            <div className='col-md-1'>
              <div className='form-group'>
                <label
                  className='fw-bolder '
                  for='username'>
                  Associate Name
                </label>
              </div>
            </div>
            <div className='col-md-4'>
              <div className='form-group '>
                <input
                  type='text'
                  className='form-control'
                  placeholder='Enter Associate Name'
                />
              </div>
            </div>
          </div>

          <div className='row mb-3'>
            <div className='col-md-1'>
              <div className='form-group'>
                <label
                  className='fw-bolder  '
                  for='userid'>
                  Email
                </label>
              </div>
            </div>
            <div className='col-md-4'>
              <div className='form-group'>
                <input
                  type='text'
                  className='form-control'
                  placeholder='Enter Email'
                />
              </div>
            </div>

            <div className='col-sm-1'></div>

            <div className='col-md-1'>
              <div className='form-group'>
                <label
                  className='fw-bolder '
                  for='username'>
                  Contact
                </label>
              </div>
            </div>
            <div className='col-md-4'>
              <div className='form-group '>
                <input
                  type='text'
                  className='form-control'
                  placeholder='Enter Contact'
                />
              </div>
            </div>
          </div>

          <div className='row mb-3'>
            <div className='col-md-1'>
              <div className='form-group'>
                <label
                  className='fw-bolder  '
                  for='userid'>
                  Grade
                </label>
              </div>
            </div>
            <div className='col-md-4'>
              <div className='form-group'>
                <select
                  id='grade'
                  className='form-select'
                  aria-label='Select Grade'>
                  <option value=''>Select Grade</option>
                  <option value='F1'>F1</option>
                  <option value='F2'>F2</option>
                  <option value='E1'>E1</option>
                  <option value='E2'>E2</option>
                  <option value='D1'>D1</option>
                  <option value='D2'>D2</option>
                  <option value='C1'>C1</option>
                  <option value='C2'>C2</option>
                </select>
              </div>
            </div>

            <div className='col-sm-1'></div>

            <div className='col-md-1'>
              <div className='form-group'>
                <label
                  className='fw-bolder '
                  for='username'>
                  Activate
                </label>
              </div>
            </div>
            <div className='col-md-4'>
              <div className='form-group '>
                <div className='form-check form-switch form-switch-md'>
                  <input
                    className='form-check-input'
                    type='checkbox'
                  />
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>
      <div style={{ marginTop: "40px" }}>
        <h4>List of roles panel can interview : </h4>
        <form>
          <table className='table table-light table-striped'>
            <thead>
              <tr>
                <th className='p-2'>#</th>
                <th className='p-2'>Roles</th>
                <th className='p-2'>Interview Type</th>
                <th className='p-2'>IsActive</th>
                <th className='p-2'></th>
                <th className='p-2'></th>
              </tr>
            </thead>
            <tbody>
              {tableData.map((item, index) => {
                return (
                  <tr>
                    <td>{index + 1}</td>
                    <td>
                      <div>
                        <select
                          defaultValue={item.role}
                          onChange={(e) => {
                            refreshDataRole(e, index);
                          }}
                          className='form-select'>
                          <option value=''>
                            Select Role
                          </option>
                          <option value='abc'>abc</option>
                          <option value='def'>def</option>
                        </select>
                      </div>
                    </td>
                    <td>
                      <div>
                        <select
                          defaultValue={item.interviewType}
                          onChange={(e) => {
                            refreshDataIntType(e, index);
                          }}
                          className='form-select'>
                          <option value=''>
                            Select Interview type
                          </option>
                          <option value='L1'>L1</option>
                          <option value='L2'>L2</option>
                          <option value='L1L2'>
                            L1 & L2
                          </option>
                          <option value='HR'>HR</option>
                        </select>
                      </div>
                    </td>
                    <td>
                      <div className='form-check form-switch'>
                        <input
                          onChange={(e) => {
                            refreshDataActive(e, index);
                          }}
                          className='form-check-input mt-2'
                          type='checkbox'
                          data-testid='checkbox'
                          role='switch'
                          id='isActive'
                        />
                      </div>
                    </td>
                    <td>
                      {index + 1 != tableData.length ? (
                        <></>
                      ) : (
                        <button
                          type='button'
                          className='btn btn-primary col-10'
                          onClick={addNewRole}>
                          Add New Role
                        </button>
                      )}
                    </td>
                    <td>
                      <BsTrashFill
                        onClick={(e) => {
                          deleteRow(e, index);
                        }}
                        className='text-primary mt-2'
                        style={{ scale: "1.5" }}>
                        delete
                      </BsTrashFill>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          <button
            style={{ marginRight: "20px" }}
            className='btn btn-primary'>
            Submit
          </button>
          <button className='btn btn-primary'>
            Cancel
          </button>
        </form>
      </div>
    </div>
  );
}

export default AddPanel;
