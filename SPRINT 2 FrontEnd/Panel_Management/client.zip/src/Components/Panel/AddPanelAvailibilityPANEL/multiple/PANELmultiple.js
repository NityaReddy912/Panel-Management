import React from "react";

function AddPanelAvailbilityPANELmultiple() {
  return (
    <div className='container-wrap px-3'>
      <p>hello</p>
    </div>
  );
}

export default AddPanelAvailbilityPANELmultiple;
