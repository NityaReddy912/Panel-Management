import React from "react";
// import "../../Main.scss";
import Paginator from "../Utils/Paginator";
import SingleList from "./SingleList";

function SearchList({
  roleList,
  page,
  onPrevious,
  onNext,
  filterName,
  isLoading,
}) {
  console.log(roleList);
  return (
    <>
      {!isLoading && (
        <>
          {roleList?.role?.length ? (
            <div className='search container'>
              <Paginator
                onPrevious={onPrevious}
                onNext={onNext}
                lastPage={
                  roleList?.role?.length
                    ? Math.ceil(roleList.totalItems / 3)
                    : 1
                }
                currentPage={page}>
                <table className='table table-striped table-hover'>
                  <thead>
                    <tr
                      style={{
                        textTransform: "capitalize",
                      }}>
                      <th scope='col'>#</th>
                      <th scope='col'>{filterName} Id</th>
                      <th scope='col'>{filterName} Name</th>
                      <th scope='col'>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {roleList.role?.map((role, index) => (
                      <SingleList
                        key={role._id}
                        hash={page * 3 - 3 + (index + 1)}
                        page={page}
                        role={role}
                        filterName={filterName}
                      />
                    ))}
                  </tbody>
                </table>
                <span>
                  {roleList?.totalItems
                    ? page * 3 -
                      2 +
                      " - " +
                      (page * 3 <= roleList?.totalItems
                        ? page * 3
                        : roleList?.totalItems) +
                      " of " +
                      Math.ceil(roleList?.totalItems) +
                      " records"
                    : ""}
                </span>
              </Paginator>
            </div>
          ) : (
            <p className='mt-5 container display-4'>
              No Data Found
            </p>
          )}
        </>
      )}
    </>
  );
}

export default SearchList;
