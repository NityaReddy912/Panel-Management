import React from "react";
import AddList from "../../Components/AddList/AddList";

function AddPanelType() {
  return <AddList filterName='panel type' />;
}

export default AddPanelType;
