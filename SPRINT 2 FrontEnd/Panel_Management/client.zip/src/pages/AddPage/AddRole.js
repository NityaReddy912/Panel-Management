import React from "react";
import AddList from "../../Components/AddList/AddList";

function AddRole() {
  return <AddList filterName='role' />;
}

export default AddRole;
