import React from "react";
import AddList from "../../Components/AddList/AddList";

function AddPanelLevel() {
  return <AddList filterName='panel level' />;
}

export default AddPanelLevel;
