import React from "react";
import AddList from "../../Components/AddList/AddList";

function AddCandidateStatus() {
  return <AddList filterName='candidate status' />;
}

export default AddCandidateStatus;
