import React from "react";
import AddList from "../../Components/AddList/AddList";

function AddGrade() {
  return <AddList filterName='grade' />;
}

export default AddGrade;
