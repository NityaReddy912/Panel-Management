import React from "react";
import UpdateList from "../../Components/UpdateList/UpdateList";

function UpdateCandidateStatus() {
  return (
    <div>
      <UpdateList filterName='candidate status' />
    </div>
  );
}

export default UpdateCandidateStatus;
