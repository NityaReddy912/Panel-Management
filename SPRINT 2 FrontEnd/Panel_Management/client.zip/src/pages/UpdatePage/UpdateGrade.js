import React from "react";
import UpdateList from "../../Components/UpdateList/UpdateList";

function UpdateGrade() {
  return (
    <div>
      <UpdateList filterName='grade' />
    </div>
  );
}

export default UpdateGrade;
