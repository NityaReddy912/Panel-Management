import React from "react";
import UpdateList from "../../Components/UpdateList/UpdateList";

function UpdateRole() {
  return (
    <div>
      <UpdateList filterName='role' />
    </div>
  );
}

export default UpdateRole;
