import React from "react";
import UpdateList from "../../Components/UpdateList/UpdateList";

function UpdatePanelLevel() {
  return (
    <div>
      <UpdateList filterName='panel level' />
    </div>
  );
}

export default UpdatePanelLevel;
